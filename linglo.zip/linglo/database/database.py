from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.future import select
from sqlalchemy import asc
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    user_id = Column(Integer, primary_key=True)
    full_name = Column(String)
    user_time = Column(DateTime)

class Word(Base):
    __tablename__ = 'words'
    
    word_id = Column(Integer, primary_key=True)
    en_word = Column(String)
    uz_word = Column(String)
    levl = Column(String)
    add_user_id = Column(Integer, ForeignKey('users.user_id'))
    add_word_time = Column(DateTime)

DATABASE_URL = "sqlite+aiosqlite:///vocabulary_bot.db"

async def init_db():
    engine = create_async_engine(DATABASE_URL, echo=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

AsyncSessionLocal = sessionmaker(
    bind=create_async_engine(DATABASE_URL, echo=True),
    class_=AsyncSession,
    expire_on_commit=False
)

async def add_user(user_id: int, full_name: str):
    async with AsyncSessionLocal() as session:
        async with session.begin():
            existing_user = await session.execute(select(User).where(User.user_id == user_id))
            if not existing_user.scalars().first():
                new_user = User(user_id=user_id, full_name=full_name, user_time=datetime.now())
                session.add(new_user)

async def add_word(en_word: str, uz_word: str, levl: str, add_user_id: int):
    async with AsyncSessionLocal() as session:
        async with session.begin():
            existing_word = await session.execute(
                select(Word).where(Word.en_word == en_word, Word.add_user_id == add_user_id)
            )
            if not existing_word.scalars().first():
                new_word = Word(
                    en_word=en_word,
                    uz_word=uz_word,
                    levl=levl,
                    add_user_id=add_user_id,
                    add_word_time=datetime.now()
                )
                session.add(new_word)

async def get_words(skip: int = 0, limit: int = 10):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Word).order_by(asc(Word.word_id)).offset(skip).limit(limit))
        return result.scalars().all()

async def get_user_words(user_id: int, skip: int = 0, limit: int = 10):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(Word).where(Word.add_user_id == user_id).order_by(asc(Word.word_id)).offset(skip).limit(limit)
        )
        return result.scalars().all()

async def get_word_count(user_id: int):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(Word).where(Word.add_user_id == user_id)
        )
        return result.scalars().count()

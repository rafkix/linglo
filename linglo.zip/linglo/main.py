import asyncio
import handlers
from data import config
from aiogram.enums import ParseMode
from database.database import init_db
from aiogram import Bot, Dispatcher, html
from aiogram.client.default import DefaultBotProperties

bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

async def main():
    """
    Main function to start the bot and handle updates.
    """
    # Start the bot and handle updates
    handlers.setup(dp)
    await bot.delete_webhook(drop_pending_updates=True)
    await bot.send_message(
        chat_id=config.ADMIN_ID,
        text="Bot ishga tushdi"
    )
    await dp.start_polling(bot)

if __name__ == '__main__':
    # Initialize the database
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Bot ishdan to'xtadi")

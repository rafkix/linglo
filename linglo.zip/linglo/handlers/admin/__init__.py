from aiogram import Dispatcher

from .admin import router as admin_router

def setup(dp: Dispatcher):
    dp.include_router(admin_router)
import logging
from sqlalchemy import select
from aiogram import Router, F
from aiogram.filters import Command
from data.config import ADMIN_ID
from database.database import Word, get_word_count, get_words
from aiogram.utils.keyboard import InlineKeyboardBuilder
from database.database import AsyncSessionLocal
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

router = Router()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def get_user_word_counts():
    try:
        async with AsyncSessionLocal() as session:
            result = await session.execute(select(Word.add_user_id).distinct())
            user_ids = result.scalars().all()
            
            word_counts = {user_id: await get_word_count(user_id) for user_id in user_ids}
            return word_counts
    except Exception as e:
        logger.error(f"Error fetching user word counts: {e}")
        return {}

@router.message(Command(commands=['admin']))
async def handle_admin(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("You are not authorized to use this command.")
        return

    keyboard = InlineKeyboardBuilder()
    keyboard.button(text="List All Words", callback_data="list_all_words")
    
    await message.answer("Admin Menu:", reply_markup=keyboard.as_markup())

# Handler to display the list of words with delete buttons
@router.callback_query(F.data == "list_all_words")
async def handle_list_all_words_callback(callback_query: CallbackQuery):
    words = await get_words()  # Retrieve all words
    if not words:
        await callback_query.answer("No words found.")
        return

    keyboard = InlineKeyboardBuilder()  # Create an InlineKeyboardBuilder instance

    for word in words:
        # Add a button for each word with a confirmation callback
        keyboard.button(
            text=f"{word.en_word} (EN) - {word.uz_word} (UZ)",
            callback_data=f"confirm_delete:{word.word_id}"  # Use the confirmation callback data
        )

     # Set a single-column layout
    keyboard.adjust(1)

    await callback_query.message.answer("Select a word to delete:", reply_markup=keyboard.as_markup())  # Send the message with the keyboard
    await callback_query.answer()  # Acknowledge the callback

## Function to build the confirmation keyboard for deletion
def build_confirmation_keyboard(word_id):
    keyboard = InlineKeyboardBuilder()  # Create an InlineKeyboardBuilder instance

    keyboard.button(
        text="Yes",
        callback_data=f"delete_word:{word_id}"  # Callback for deletion
    )
    keyboard.button(
        text="No",
        callback_data="cancel_delete"  # Callback to cancel deletion
    )

    return keyboard.as_markup()  # Return the markup

# Handler to confirm the deletion of a word
@router.callback_query(F.data.startswith('confirm_delete:'))
async def handle_confirm_delete_callback(callback_query: CallbackQuery):
    word_id = int(callback_query.data.split(':')[1])  # Extract word ID from callback data

    # Build confirmation keyboard
    confirmation_keyboard = build_confirmation_keyboard(word_id)

    await callback_query.message.edit_text(
        f"Are you sure you want to delete the word with ID: {word_id}?",
        reply_markup=confirmation_keyboard
    )
    await callback_query.answer()  # Acknowledge the callback

# Handler for the actual deletion of the word after confirmation
@router.callback_query(F.data.startswith('delete_word:'))
async def handle_delete_word_callback(callback_query: CallbackQuery):
    if callback_query.from_user.id != ADMIN_ID:
        await callback_query.answer("You are not authorized to perform this action.")
        return

    word_id = int(callback_query.data.split(':')[1])  # Extract word ID from callback data

    async with AsyncSessionLocal() as session:
        async with session.begin():
            result = await session.execute(select(Word).where(Word.word_id == word_id))
            word_to_delete = result.scalars().first()
            if word_to_delete:
                await session.delete(word_to_delete)
                await callback_query.answer(f"Deleted word with ID: {word_id}.")
                words = await get_words()  # Retrieve all words
                if not words:
                    await callback_query.answer("No words found.")
                    return

                keyboard = InlineKeyboardBuilder()  # Create an InlineKeyboardBuilder instance

                for word in words:
                    # Add a button for each word with a confirmation callback
                    keyboard.button(
                        text=f"{word.en_word} (EN) - {word.uz_word} (UZ)",
                        callback_data=f"confirm_delete:{word.word_id}"  # Use the confirmation callback data
                    )

                # Set a single-column layout
                keyboard.adjust(1)

                await callback_query.message.edit_text("Word deleted successfully.", reply_markup=keyboard.as_markup())
            else:
                await callback_query.answer(f"No word found with ID: {word_id}.")

# Optional: Handler to cancel deletion
@router.callback_query(F.data == "cancel_delete")
async def handle_cancel_delete(callback_query: CallbackQuery):
    await callback_query.answer("Deletion canceled.")
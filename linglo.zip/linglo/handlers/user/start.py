from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, WebAppInfo, KeyboardButton, ReplyKeyboardMarkup

from database.database import add_user

router = Router()

@router.message(CommandStart())
async def send_welcome(message: Message):
    await add_user(message.from_user.id, message.from_user.full_name)
    await message.answer(
        text=f"<b>Assalomu alaykum <i>lingl</i> loyihasining demo botiga xush kelibsiz!\n\n "
             f"Marxamat terakli fungsiyalar bilan tanishish orqali /help komandasni yuboring.</b>"
        )

@router.message(Command('help'))
async def send_help(message: Message):
    await message.answer(
        text="<b>Marxamat terakli fungsiyalar:\n\n</b>"
        f"/add_word - Ynagi so'zni qo'shish\n"
        f"/all_words - Bazadgi barcha so'zlar\n"
        f"/my_words - Siz qo'shgan so'zlar\n"
        f"")
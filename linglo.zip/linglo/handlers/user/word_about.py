import os
from main import bot
from gtts import gTTS
from aiogram import Router, F
from api.synonyms import get_synonyms, get_definitions, get_pronunciation
from database.database import add_word, get_words
from aiogram.types import Message, CallbackQuery, InputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder

router = Router()



@router.callback_query(lambda c: c.data.startswith("word:"))
async def handle_word_callback(callback_query: CallbackQuery):
    en_word = callback_query.data.split(":")[1]
    
    # Fetch word details
    word_synonyms = await get_synonyms(word=en_word)
    word_definitions = await get_definitions(word=en_word)
    word_pronunciation = await get_pronunciation(word=en_word)

    synonyms_text = ', '.join(word_synonyms['synonyms'])

    # Construct the response message
    response_message = f"<b>So'z: {en_word}</b>\n\n"
    response_message += f"<b>Sinonimlari: {synonyms_text}</b>\n"
    definitions_text = "\n".join(word_definitions)  # Join definitions with a newline
    response_message += f"<b>Ta'riflar:</b> {definitions_text}\n"
    response_message += f"<b>Talafuz: {word_pronunciation}</b>"

    keyboard = InlineKeyboardBuilder()
    keyboard.button(text="⬅️ Barcha so'zlarga qaytish", callback_data="back_to_list")
    # keyboard.button(text="🔊 Audio Yuklash", callback_data=f"audio:{en_word}")  # New button for audio
    keyboard.adjust(1)

    # Send the message
    await callback_query.message.edit_text(text=response_message, reply_markup=keyboard.as_markup(), parse_mode='HTML')
    await callback_query.answer()  # Acknowledge the callback

@router.callback_query(lambda c: c.data.startswith("voice:"))
async def handle_voice_callback(callback_query: CallbackQuery):
    en_word = callback_query.data.split(":")[1]

    # Generate voice message using gTTS
    tts = gTTS(text=en_word, lang='en', slow=False)  # Generate audio in English
    audio_filename = f"{callback_query.message.message_id}_{en_word}.mp3"  # Name the voice file

    # Save the audio to an OGG file
    tts.save(audio_filename)

    # Check if the file exists before sending
    if os.path.exists(audio_filename):
        # Use InputFile to send the voice message
        voice_file = InputFile(audio_filename)
        await bot.send_audio(
            chat_id=callback_query.from_user.id,
            audio=voice_file,
            caption=f"{en_word} uchun ovoz"
        )
        os.remove(audio_filename)  # Clean up after sending
    else:
        await callback_query.answer("Ovozli fayl topilmadi.")  # Error handling

    await callback_query.answer()  # Acknowledge the callback




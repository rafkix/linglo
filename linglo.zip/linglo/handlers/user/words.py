from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from api.synonyms import get_pronunciation, get_synonyms
from database.database import add_word, get_user_words, get_words
from aiogram.utils.keyboard import InlineKeyboardBuilder

router = Router()

@router.message(Command("add_word"))
async def handle_add_word(message: Message):
    args = message.text.split(maxsplit=4)
    if len(args) < 4:
        await message.answer(
            text="<b>Foydalanish: <code>/add_word hello salom A2</code></b>"
            )
        return

    en_word = args[1]
    uz_word = args[2]
    levl = args[3]

    await add_word(en_word, uz_word, levl, message.from_user.id)
    await message.answer(
        text=f"<b>Qo'shilgan so'z: {en_word} (EN) - {uz_word} (UZ) - {levl} (Darajadagi so'z)</b>"
        )

user_pages = {}



@router.message(Command('all_words'))
async def handle_all_words(message: Message):
    user_pages[message.from_user.id] = 1  # Reset to first page
    await display_words(message, page=1)

async def display_words(message: Message | CallbackQuery, page: int):
    limit = 10
    skip = (page - 1) * limit
    words = await get_words(skip=skip, limit=limit)

    if not words:
        await message.answer("So'zlar topilmadi.")
        return

    # Create an inline keyboard with each word as a button, arranged vertically
    keyboard = InlineKeyboardBuilder()
    for word in words:
        keyboard.button(text=f"{word.en_word} (EN) - {word.uz_word} (UZ)", callback_data=f"word:{word.en_word}")

    # Determine whether to show navigation buttons
    if page > 1:
        keyboard.button(text="⬅️ Oldingi", callback_data=f"prev_page:{page}")
    if len(words) == limit:
        keyboard.button(text="Keyingi ➡️", callback_data=f"next_page:{page}")

    # Set a single-column layout
    keyboard.adjust(1)

    # Send or edit the message based on whether it's a command or callback query
    if isinstance(message, Message):
        await message.answer("So'zni tanlang:", reply_markup=keyboard.as_markup())
    elif isinstance(message, CallbackQuery):
        await message.message.edit_text("So'zni tanlang:", reply_markup=keyboard.as_markup())

@router.callback_query(lambda c: c.data.startswith("prev_page:") or c.data.startswith("next_page:"))
async def handle_page_callback(callback_query: CallbackQuery):
    page = int(callback_query.data.split(":")[1])
    user_id = callback_query.from_user.id

    # Update page based on callback data
    new_page = page - 1 if "prev_page" in callback_query.data else page + 1

    user_pages[user_id] = new_page
    await display_words(callback_query, page=new_page)  # This will call edit_text
    await callback_query.answer()  # Acknowledge the callback to prevent loading indicator

@router.callback_query(lambda c: c.data == "back_to_list")
async def handle_back_to_list(callback_query: CallbackQuery):
    # Retrieve the page number for the current user
    user_id = callback_query.from_user.id
    page = user_pages.get(user_id, 1)  # Default to page 1 if not set

    # Edit the existing message to display the word list on the current page
    await display_words(callback_query, page=page)  # This will call edit_text
    await callback_query.answer()  # Acknowledge the callback

@router.message(Command(commands=['my_words']))
async def handle_my_words(message: Message):
    user_pages[message.from_user.id] = 1  # Reset to first page
    await display_my_words(message, page=1)

async def display_my_words(message: Message | CallbackQuery, page: int):
    limit = 10
    skip = (page - 1) * limit
    words = await get_user_words(message.from_user.id, skip=skip, limit=limit)

    if not words:
        await message.answer("So'zlar topilmadi.")
        return

    # Create an inline keyboard with each word as a button, arranged vertically
    keyboard = InlineKeyboardBuilder()
    for word in words:
        keyboard.button(text=f"{word.en_word} (EN) - {word.uz_word} (UZ)", callback_data=f"word:{word.en_word}")

    # Determine whether to show navigation buttons
    if page > 1:
        keyboard.button(text="⬅️ Oldingi", callback_data=f"my_prev_page:{page}")
    if len(words) == limit:
        keyboard.button(text="Keyingi ➡️", callback_data=f"my_next_page:{page}")

    # Set a single-column layout
    keyboard.adjust(1)

    # Send or edit the message based on whether it's a command or callback query
    if isinstance(message, Message):
        await message.answer("So'zni tanlang:", reply_markup=keyboard.as_markup())
    elif isinstance(message, CallbackQuery):
        await message.message.edit_text("So'zni tanlang:", reply_markup=keyboard.as_markup())

@router.callback_query(lambda c: c.data.startswith("my_prev_page:") or c.data.startswith("my_next_page:"))
async def handle_page_callback(callback_query: CallbackQuery):
    page = int(callback_query.data.split(":")[1])
    user_id = callback_query.from_user.id

    # Update page based on callback data
    new_page = page - 1 if "prev_page" in callback_query.data else page + 1

    user_pages[user_id] = new_page
    await display_words(callback_query, page=new_page)  # This will call edit_text
    await callback_query.answer()  # Acknowledge the callback to prevent loading indicator

from aiogram import Dispatcher

from .start import router as start_router
from .words import router as words_router
from .word_about import router as word_about_router


def setup(dp: Dispatcher):
    dp.include_router(start_router)
    dp.include_routers(words_router)
    dp.include_routers(word_about_router)
import httpx

async def get_synonyms(word):
    url = f"https://wordsapiv1.p.rapidapi.com/words/{word}/synonyms"
    headers = {
        "x-rapidapi-key": "4e45f78b94msh3a88deac3b7065bp17ceb1jsn374ec47a55ff",
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers)
        data = response.json()
        synonyms = data.get("synonyms", [])[:3]  # Get the first three synonyms
        return {"synonyms": synonyms}

async def get_pronunciation(word):
    url = f"https://wordsapiv1.p.rapidapi.com/words/{word}/pronunciation"
    headers = {
        "x-rapidapi-key": "4e45f78b94msh3a88deac3b7065bp17ceb1jsn374ec47a55ff",
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers)
        data = response.json()
        pronunciation_data = data.get("pronunciation", {})
        pronunciation = pronunciation_data.get("all", "")  # Get the 'all' key or an empty string if it doesn't exist
        
        return pronunciation  # Return the pronunciation string directly
    
async def get_definitions(word):
    url = f"https://wordsapiv1.p.rapidapi.com/words/{word}/definitions"
    headers = {
        "x-rapidapi-key": "4e45f78b94msh3a88deac3b7065bp17ceb1jsn374ec47a55ff",
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers)
        data = response.json()
        # Extract definitions and format them as a list of strings
        definitions = data.get("definitions", [])
        formatted_definitions = [f"{item['definition']} ({item['partOfSpeech']})" for item in definitions]
        
        return formatted_definitions  # Return the list of formatted definitions
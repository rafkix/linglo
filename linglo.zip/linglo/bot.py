# from aiogram import Bot, Dispatcher, types, F
# from aiogram.filters import Command, CommandStart
# from aiogram.utils.keyboard import InlineKeyboardBuilder


# # Replace with your actual admin user ID






# @dp.message(Command(commands=['my_words']))
# async def handle_my_words(message: types.Message):
#     user_pages[message.from_user.id] = 1  # Reset to first page
#     await display_my_words(message, page=1)

# async def display_my_words(message: types.Message, page: int):
#     limit = 10
#     skip = (page - 1) * limit
#     words = await get_user_words(message.from_user.id, skip=skip, limit=limit)

#     if not words:
#         await message.answer("You haven't added any words yet.")
#         return

#     response = "\n".join([f"{word.en_word} (EN) - {word.uz_word} (UZ)" for word in words])
    
#     keyboard = InlineKeyboardBuilder()
#     if page > 1:
#         keyboard.button(text="Previous", callback_data=f"my_prev_page:{page}")
#     keyboard.button(text="Next", callback_data=f"my_next_page:{page}")

#     await message.answer(response, reply_markup=keyboard.as_markup())

# @dp.callback_query(F.data.startswith('my_next_page:'))
# async def process_my_next_page(callback_query: types.CallbackQuery):
#     page = int(callback_query.data.split(':')[1])
#     await display_my_words(callback_query.message, page + 1)
#     await callback_query.answer()

# @dp.callback_query(F.data.startswith('my_prev_page:'))
# async def process_my_prev_page(callback_query: types.CallbackQuery):
#     page = int(callback_query.data.split(':')[1])
#     if page > 1:
#         await display_my_words(callback_query.message, page - 1)
#     await callback_query.answer()

# import logging

# # Set up logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# async def get_user_word_counts():
#     try:
#         async with AsyncSessionLocal() as session:
#             result = await session.execute(select(Word.add_user_id).distinct())
#             user_ids = result.scalars().all()
            
#             word_counts = {}
#             for user_id in user_ids:
#                 count = await get_word_count(user_id)
#                 word_counts[user_id] = count
            
#             return word_counts
#     except Exception as e:
#         logger.error(f"Error fetching user word counts: {e}")
#         return {}

# @dp.message(Command(commands=['admin']))
# async def handle_admin(message: types.Message):
#     if message.from_user.id != ADMIN_ID:
#         await message.answer("You are not authorized to use this command.")
#         return

#     keyboard = InlineKeyboardBuilder()
#     keyboard.button(text="List All Words", callback_data="list_all_words")
#     keyboard.button(text="View User Word Counts", callback_data="view_user_word_counts")
    
#     await message.answer("Admin Menu:", reply_markup=keyboard.as_markup())



# @dp.callback_query(F.data == "list_all_words")
# async def handle_list_all_words_callback(callback_query: types.CallbackQuery):
#     words = await get_words()  # Retrieve all words
#     if not words:
#         await callback_query.answer("No words found.")
#         return

#     response = "\n".join([f"ID: {word.word_id}, {word.en_word} (EN) - {word.uz_word} (UZ)" for word in words])
    
#     await callback_query.message.answer(response)
#     await callback_query.answer()  # Acknowledge the callback

# @dp.callback_query(F.data == "view_user_word_counts")
# async def handle_view_user_word_counts(callback_query: types.CallbackQuery):
#     user_word_counts = await get_user_word_counts()  # Get user word counts
#     response = "\n".join([f"User ID: {user_id}, Words: {count}" for user_id, count in user_word_counts.items()])
    
#     await callback_query.message.answer(response or "No words added by users.")
#     await callback_query.answer()  # Acknowledge the callback



# @dp.callback_query(F.data.startswith('delete_word:'))
# async def handle_delete_word_callback(callback_query: types.CallbackQuery):
#     if callback_query.from_user.id != ADMIN_ID:
#         await callback_query.answer("You are not authorized to perform this action.")
#         return

#     word_id = int(callback_query.data.split(':')[1])  # Extract word ID from callback data

#     async with AsyncSessionLocal() as session:
#         async with session.begin():
#             result = await session.execute(select(Word).where(Word.word_id == word_id))
#             word_to_delete = result.scalars().first()
#             if word_to_delete:
#                 await session.delete(word_to_delete)
#                 await callback_query.answer(f"Deleted word with ID: {word_id}.")
#                 await callback_query.message.edit_text("Word deleted successfully.")
#             else:
#                 await callback_query.answer(f"No word found with ID: {word_id}.")

